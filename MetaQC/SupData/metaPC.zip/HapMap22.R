#change it to your directory
gear='java -jar /Users/gc5k/Documents/workspace/FromSVN/GEAR/gear.jar'
####
mpc=paste(gear, " mpc --meta-batch meta-frq.txt --qt-size meta-size.txt --key SNP CHR A1 A2 MAF --out hapmap_22")
system(mpc)
hap=read.table("hapmap_22.mvec", as.is = T)
plot(hap[,1], hap[,2], xlab="mPC 1", ylab="mPC 2", frame.plot = F)

####the index of each population as specified in meta-frq.txt
#Africans
points(hap[18,1], hap[18,2], pch=16, col="blue")
text(hap[18,1], hap[18,2], labels = c("MSL"))

points(hap[25,1], hap[25,2], pch=16, col="blue")
text(hap[25,1], hap[25,2], labels = c("YRI"))

#Asians
points(hap[5,1], hap[5,2], pch=16, col="pink")
text(hap[5,1], hap[5,2], labels = c("CHB"))

points(hap[15,1], hap[15,2], pch=16, col="pink")
text(hap[15,1], hap[15,2], labels = c("JPT"))

#Europeans
points(hap[4,1], hap[4,2], pch=16, col="red")
text(hap[4,1], hap[4,2], labels = c("CEU"))
points(hap[24,1], hap[24,2], pch=16, col="red")
text(hap[24,1], hap[24,2], labels = c("TSI"))

