java -jar gear.jar lam --meta-batch meta.list --qt-size size.list --key SNP BETA SE A1 A2 CHR BP P --out test
